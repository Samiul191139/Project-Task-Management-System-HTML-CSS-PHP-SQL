-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2024 at 06:29 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`) VALUES
(22303305, 'Alif', 'alif123@gmail.com', '$2y$10$dGaEemX6WbrMEn8RhgjJ8OBogZcNyqD6fU8/9pWEDGBeaqwAHz7qG'),
(22303308, 'samiul', 'samikarim191139@gmail.com', '$2y$10$NQoK7v1lcM/VwQwjdY.K2uGEvoW.c465PM8BywEgT6n5HBLW3poV.');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(12) NOT NULL,
  `type` varchar(25) NOT NULL,
  `password` char(255) NOT NULL,
  `email` varchar(25) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `type`, `password`, `email`, `date`) VALUES
(2, 'users', '$2y$10$Er8yI/0AbEo8PUF1vQO9AOVDcpx8YUaQrlxjh9JXdvTCGK0fNSzJK', 'test2@gmail.com', '0000-00-00 00:00:00'),
(2, 'users', '$2y$10$RzGb/83u3GsFlAOM0G0o5.m6rkaxUpEF6x1TjTnEBKmhUsXRcNugi', 'test2@gmail.com', '0000-00-00 00:00:00'),
(2, 'users', '$2y$10$CsG1h6vieeuULaSsToIZausEKvnspbOJHvRJIxQcaWnT1NVjM.pfO', 'test2@gmail.com', '0000-00-00 00:00:00'),
(2, 'users', '$2y$10$mMxpYY1nO3BQD.AWDSz/p.fyRdPsLglKVF91RKbilXy4FqWn3jZo6', 'test2@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '$2y$10$BKUo8h3WCW7JLXWFX.poUezQmT40sr3p/7uktnwHa4w5BIMZdUvpq', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '$2y$10$IN40nZZNwogR.d9kpboVaeWUrs/C1FitaTKoKyvQc8l0v1uSmXHvK', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '$2y$10$yxDR/050RsL9xGtMjyhaz.SruTdeYC40K3UPUwIJre8XvfHGMed36', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '$2y$10$uQ/GuKHfEvJxqxzZ5KZ/oe5Tl/Okha5xESk7MTV/lw4PNWLYHTtKW', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'users', '$2y$10$XJAX32G0TXAgoc4t6iZ3u.gFneOhdDacLaZY0aWZk.CIr3Qh3fVPK', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '$2y$10$nByags0MXitR48JNeQBDx.CXoRpLXxulPEk050lbj/olz6CiCJF7y', 'abcd@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '$2y$10$NQoK7v1lcM/VwQwjdY.K2uGEvoW.c465PM8BywEgT6n5HBLW3poV.', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '$2y$10$NQoK7v1lcM/VwQwjdY.K2uGEvoW.c465PM8BywEgT6n5HBLW3poV.', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-20 23:57:32'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-21 00:10:34'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:11:01'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:15:02'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:20:32'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:20:39'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:23:29'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:31:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:31:19'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:58:34'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-24 23:31:29'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-24 23:37:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-24 23:37:22'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-24 23:50:39'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-24 23:51:10'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-26 11:48:36'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-26 12:04:07'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:00:01'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:08:34'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:10:08'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:11:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:14:49'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:21:58'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:45:37'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 01:12:25'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 01:17:41'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 01:26:47'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 23:01:05'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 23:18:58'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 23:57:53'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 00:18:57'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 00:28:43'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 00:31:41'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 12:58:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 13:09:31'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 13:18:48'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 13:19:31'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 16:03:33'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 16:05:06'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 16:12:14'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 16:12:56'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 20:28:30'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:09:29'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:10:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:10:15'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:29:45'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:31:06'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 11:18:47'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-29 11:22:15'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 11:23:07'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-29 12:56:43'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 21:46:50'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 21:47:46'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 21:50:50'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-29 21:51:15'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-29 22:04:51'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 22:05:09'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 22:10:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 22:22:18'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 23:00:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 23:13:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 23:14:25'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 23:20:21'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 23:30:05'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 00:27:05'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 01:47:09'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 02:07:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 03:07:24'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 11:37:08'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 11:52:34'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-04-30 12:17:02'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 12:17:45'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 12:57:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 13:01:47'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 20:59:20'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 22:28:46'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 22:54:39'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 22:59:54'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-30 23:03:56'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:07:24'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:18:53'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-30 23:23:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:24:23'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-30 23:25:59'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:28:11'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:02:13'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:08:22'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:08:50'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:10:01'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:11:32'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:11:57'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:12:31'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:15:32'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:16:20'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:16:57'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:21:21'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:22:38'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:37:24'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:38:22'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:39:11'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:41:26'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-18 21:57:06'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-18 22:14:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-18 22:43:45'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-18 23:31:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-18 23:31:57'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-18 23:33:17'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-18 23:42:06'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 00:12:56'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 00:15:51'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 00:31:16'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 00:31:57'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 00:34:31'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 00:37:01'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 00:53:34'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 01:08:48'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 01:11:48'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 01:16:02'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 16:32:16'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 16:35:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 20:50:58'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 20:57:46'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 21:01:22'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 22:30:12'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 22:30:39'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 23:45:30'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 23:50:26'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 23:59:20'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 01:07:07'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 01:13:13'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-20 01:27:43'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 23:31:49'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 23:34:09'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 23:44:37'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 23:51:14'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 00:04:28'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 00:05:14'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 00:12:32'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-21 00:32:00'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 00:32:11'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 21:23:21'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 21:50:46'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-21 21:51:16'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-05-21 21:56:27'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 22:56:27'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-21 22:56:42'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-21 23:57:41'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 00:06:24'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 13:57:43'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 14:02:59'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 16:35:11'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 16:49:34'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:06:12'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 17:17:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:23:40'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 17:41:58'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:54:52'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:56:53'),
(3, 'users', '1234', 'test3@gmail.com', '2024-05-22 17:57:16'),
(5, 'users', '1234', 'test5@gmail.com', '2024-05-22 17:57:36'),
(5, 'users', '1234', 'test5@gmail.com', '2024-05-22 17:58:41'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:59:55'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-05-22 18:04:51'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 20:08:27'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 20:09:21'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 20:12:22'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 20:12:47'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 20:20:44'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 20:21:18'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 20:50:02'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 20:53:26'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 20:57:06'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 21:05:47');

-- --------------------------------------------------------

--
-- Table structure for table `logout`
--

CREATE TABLE `logout` (
  `id` int(11) NOT NULL,
  `type` varchar(25) NOT NULL,
  `password` char(255) NOT NULL,
  `email` varchar(25) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logout`
--

INSERT INTO `logout` (`id`, `type`, `password`, `email`, `date`) VALUES
(2, 'users', '1234', 'test2@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '0000-00-00 00:00:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-15 23:25:30'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-15 23:38:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-15 23:41:10'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-16 00:15:30'),
(0, '', '', '', '2024-04-16 00:15:55'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-16 00:38:52'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-17 00:41:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-17 23:10:17'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-04-17 23:12:15'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-17 23:17:01'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-17 23:28:23'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-17 23:28:42'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-17 23:29:29'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-20 23:45:29'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-20 23:46:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-20 23:54:12'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-20 23:57:27'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-20 23:57:46'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:10:04'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:14:57'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:20:29'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:30:58'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-21 00:58:30'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-24 23:36:59'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-24 23:50:22'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-24 23:51:05'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-26 12:35:30'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-27 00:45:33'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 00:28:39'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 00:31:36'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 13:07:36'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 16:12:53'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:09:59'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:10:12'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:29:42'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-28 21:30:55'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 11:21:56'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-29 11:23:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 12:52:05'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 21:47:05'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 21:50:46'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 21:51:05'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-29 22:05:05'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 22:05:17'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-29 22:10:28'),
(0, '', '', '', '2024-04-29 22:42:36'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 22:42:42'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 23:14:21'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-29 23:19:33'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 11:51:20'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 12:16:24'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-04-30 12:17:33'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 12:57:40'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 20:59:16'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 22:24:40'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 22:58:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:03:39'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-30 23:04:31'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:10:41'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:23:34'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-30 23:24:18'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:25:52'),
(2, 'users', '1234', 'test2@gmail.com', '2024-04-30 23:28:06'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-04-30 23:29:08'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:05:02'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:08:32'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:09:54'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:11:10'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:11:49'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:15:24'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:16:48'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:21:12'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:22:33'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:23:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:38:17'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-15 21:39:00'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:39:36'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-15 21:42:03'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-18 23:33:09'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 00:12:52'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 00:15:43'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 00:31:10'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 00:31:32'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 00:42:12'),
(0, '', '', '', '2024-05-19 01:08:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 01:11:32'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 01:11:44'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 01:15:51'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 20:50:08'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-19 20:57:40'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 21:01:05'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-19 21:02:13'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 01:27:38'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-20 01:27:55'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-20 23:44:27'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 00:31:55'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-21 00:32:06'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 00:36:56'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 21:51:11'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-21 21:56:20'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-05-21 21:56:48'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-21 22:56:36'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-21 22:57:31'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 00:06:17'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 00:06:34'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 13:59:23'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 16:49:29'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 17:05:58'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:16:52'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 17:23:36'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:41:53'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 17:54:39'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:56:35'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-05-22 17:57:08'),
(3, 'users', '1234', 'test3@gmail.com', '2024-05-22 17:57:28'),
(5, 'users', '1234', 'test5@gmail.com', '2024-05-22 17:57:55'),
(5, 'users', '1234', 'test5@gmail.com', '2024-05-22 17:59:49'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 18:03:55'),
(1, 'users', '12345678', 'samikarim191139@gmail.com', '2024-05-22 18:05:37'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 20:08:57'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 20:12:16'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 20:20:26'),
(22303308, 'admins', '12345678', 'samikarim191139@gmail.com', '2024-05-22 20:53:20'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 21:02:55'),
(0, '', '', '', '2024-05-22 21:02:59'),
(2, 'users', '1234', 'test2@gmail.com', '2024-05-22 21:05:55');

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `description` varchar(255) NOT NULL,
  `total_percentage` float NOT NULL DEFAULT 0,
  `Date` date NOT NULL DEFAULT current_timestamp(),
  `due_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `name`, `description`, `total_percentage`, `Date`, `due_date`) VALUES
(1, 'project 1', 'Project 1 do by 20th may', 33.3333, '2024-05-19', '2024-05-22'),
(2, 'project 2', 'Do project 2 by 21th may', 66.6667, '2024-05-19', '2024-05-22'),
(3, 'Pro 3', 'do pro 3', 0, '2024-05-19', '2024-05-22'),
(4, 'Project 6', 'Do it!', 50, '2024-05-19', '2024-05-22'),
(5, 'Project 5', 'Do it', 50, '2024-05-19', '2024-05-22'),
(6, 'project 6', 'do it!', 0, '2024-05-19', '2024-05-22'),
(7, 'project 7', 'do it for my sake please', 0, '2024-05-21', '2024-05-22'),
(8, 'pro 8', 'do them pro 8', 0, '2024-05-22', '2024-05-24'),
(9, 'pro9', 'do it', 100, '2024-05-22', '2024-05-25');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `description` char(255) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `status` char(25) NOT NULL DEFAULT 'Incomplete',
  `Date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `project_id`, `description`, `employee_id`, `status`, `Date`) VALUES
(1, 1, 'task 1', 22303318, 'Incomplete', '2024-05-19'),
(1, 2, 'do task 1', 2, 'completed', '2024-05-19'),
(1, 3, 'do task 1', 2, 'on going', '2024-05-19'),
(1, 4, 'do task 1', 1, 'completed', '2024-05-19'),
(1, 5, 'hehe', 22303318, 'Incomplete', '2024-05-19'),
(1, 6, 'do task 1', 22303318, 'Incomplete', '2024-05-19'),
(1, 7, 'do task 1', 22303318, 'Incomplete', '2024-05-21'),
(1, 8, 'do 2', 2, 'incomplete', '2024-05-22'),
(1, 9, 'task 1', 2, 'completed', '2024-05-22'),
(2, 1, 'task 2', 2, 'completed', '2024-05-19'),
(2, 2, 'do task 2', 2, 'completed', '2024-05-19'),
(2, 3, 'do task 2', 3, 'incomplete', '2024-05-19'),
(2, 4, 'do task 2', 4, 'Incomplete', '2024-05-19'),
(2, 5, 'huhu', 3, 'completed', '2024-05-19'),
(2, 6, 'Do task 2', 2, 'on going', '2024-05-19'),
(2, 7, 'do task 2', 4, 'Incomplete', '2024-05-21'),
(2, 9, 'task 2', 5, 'completed', '2024-05-22'),
(3, 1, 'task 3', 5, 'incomplete', '2024-05-19'),
(3, 2, 'do task 3', 22303318, 'Incomplete', '2024-05-19'),
(3, 6, 'do task 3', 5, 'incomplete', '2024-05-19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'samiul', 'samikarim191139@gmail.com', '$2y$10$BkNHcPaDrEy2JVBchQxmj.p7Um/p16WdE0gRt7zupVgoIZoeuKOF6'),
(2, 'test2', 'test2@gmail.com', '$2y$10$2T4Nnx.B5oXAjq4gb7kkvuR6UU7ZYnlHecik7KznBRtXabEoclVjO'),
(3, 'test3', 'test3@gmail.com', '$2y$10$rpoLy5HHKcqqjykPxo1.eec2qCz6aGR2Qyetmczu7PHyxVgs7OUHG'),
(4, 'test4', 'test4@gmail.com', '$2y$10$KNvYzw.0ox/W3xHjWwJO8uAm1x1fqhRruoaYOnNIW5.OafVzZ21u.'),
(5, 'test5', 'test5@gmail.com', '$2y$10$q2E22sl5LQTg.StA36lLLOu8c4xm6Vt/vYEyLjF4ymbiHel8iNR8i'),
(22303318, 'mahin', 'mahin@gmail.com', '$2y$10$jKMt1D68BlTePG.JoN72ee5hedoPhQmXXSRVIkEl2VW3dtQpGOie.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`id`,`project_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22303309;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22303319;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
